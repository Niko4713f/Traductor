package co.edu.unbosque.controller;

public class Controlador {

	public Controlador() {
		// TODO Auto-generated constructor stub
	}

}
